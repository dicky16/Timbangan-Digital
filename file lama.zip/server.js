const express = require('express');
const path = require('path');
const mysql = require('mysql');
const session = require('express-session');
// const expressLayouts = require('express-ejs-layouts')

const app = express();
const port = process.env.PORT || 8080;


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'shofiq2001',
    database: 'Timbangan'
});

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'static')));

app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

// http://localhost:8080/
app.get('/', function (request, response) {
    // Render login template
    response.sendFile(path.join(__dirname + '/static/login.html'));
    // res.render('/login.html');
});

// http://localhost:8080/auth
app.post('/login', function (request, response) {
    // Capture the input fields
    let username = request.body.username;
    let password = request.body.password;
    let role = request.body.role;
    // Ensure the input fields exists and are not empty
    if (username && password) {
        // Execute SQL query that'll select the account from the database based on the specified username and password
        connection.query('SELECT * FROM user WHERE username = ? AND password = ?', [username, password], function (error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) throw error;
            // If the account exists
            if (results.length > 0) {
                // Authenticate the user
                request.session.loggedin = true;
                request.session.username = username;
                request.session.role = role;
                // Redirect to home page
                response.redirect('/home');
            } else {
                response.redirect('/');
            }
            response.end();
        });
    } else {
        response.send('Please enter Username and Password!');
        response.end();
    }
});
// // http://localhost:8080/
// app.get('/dashboard', function (request, response) {
//     // Render login template
//     response.sendFile(path.join(__dirname + '/home.html'));
// });

// http://localhost:8080/home
app.get('/home', function (request, response) {
    // If the user is loggedin
    if (request.session.loggedin) {
        // Output username
        // response.send('Welcome back, ' + request.session.username + '!');
        // response.redirect('/dashboard'); opsi    1
        response.render(path.join(__dirname + '/home.html'));

    } else {
        // Not logged in
        // response.send('Please login to view this page!');
        response.redirect('/');
    }
    response.end();
});

//bootstrap
app.use('/css', express.static(__dirname + '/node_modules/bootstrap/dist/css'));

app.listen(port);
console.log('Server started at http://localhost:' + port);